Euphony for macOS - Quick Install & Gatekeeper Bypass
======================================================

1. Drag "Euphony.app" into your Applications folder.

2. Apple Gatekeeper Bypass:
   Because this app is downloaded directly from the official website (not Apple App Store):
   - Right-Click (or Control + Click) "Euphony.app"
   - Select "Open" from the menu
   - When macOS asks "Are you sure you want to open it?", click "Open".
   (You only need to do this once. macOS will remember your choice!)

3. Alternative Terminal 1-line unlock:
   Open Terminal and run:
   xattr -cr /Applications/Euphony.app

Enjoy streaming and stem-separating with Euphony!
